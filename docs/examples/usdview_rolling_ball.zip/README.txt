USD rolling ball: orange basketball with black seams

Extract the entire archive. Keep docs/ and icons/ beside one another.
Open docs/examples/tutorial_rolling_ball.usda in a usdRig-enabled usdview.
Scrub 1001-1049 for travel-driven rolling.
Open docs/examples/tutorial_rolling_ball_free.usda for the Godot bake source.

The basketball image texture in docs/examples/textures is shared by both
USD variants through face-varying UVs and a UsdPreviewSurface material.
The stage's rig, controllers and material remain editable.

Legal texts in this archive: LICENSE, NOTICE, THIRD_PARTY_NOTICES.md, thirdparty/flatbuffers/LICENSE, thirdparty/lzma/NOTICE.md, thirdparty/lzma/DOC/lzma-sdk.txt, plugin/usdNoodles/LICENSE.txt, plugin/usdNoodles/NOODLES_LICENSE.txt, plugin/usdNoodles/THIRD_PARTY_LICENSES.txt, tools/license_manifest.json, LICENSE-usdRig, NOTICE-usdRig, LICENSE-OpenUSD, THIRD_PARTY_NOTICES-usdRig.md.
The links inside THIRD_PARTY_NOTICES.md use the same source-relative paths as
the repository and the installed usdRig prefix, so they resolve here.
docs/references.md and docs/concepts/riglogic.md are documentation prose, not
legal texts, and ship only in the source checkout.

Live rig evaluation requires the usdRig schema and imaging plugins.

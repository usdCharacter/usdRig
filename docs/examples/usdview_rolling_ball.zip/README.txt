USD rolling ball: orange basketball with black seams

Extract the entire archive. Keep docs/ and icons/ beside one another.
Open docs/examples/tutorial_rolling_ball.usda in a usdRig-enabled usdview.
Scrub 1001-1049 for travel-driven rolling.
Open docs/examples/tutorial_rolling_ball_free.usda for the Godot bake source.

The basketball image texture in docs/examples/textures is shared by both
USD variants through face-varying UVs and a UsdPreviewSurface material.
The stage's rig, controllers and material remain editable.

Legal texts in this archive: LICENSE-usdRig, NOTICE-usdRig, LICENSE-OpenUSD, THIRD_PARTY_NOTICES-usdRig.md.

Live rig evaluation requires the usdRig schema and imaging plugins.

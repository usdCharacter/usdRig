#include "rigexec_player.h"
#include "rigexec_character.h"
#include "rigExecRuntime/runtime.h"
// The presentation schema; its generated header needs format.h's types.
#include "rigExecBinary/format.h"
#include "flatbuffers/verifier.h"
#include <godot_cpp/classes/image.hpp>
#include <godot_cpp/classes/image_texture.hpp>
#include <godot_cpp/classes/json.hpp>
#include <godot_cpp/classes/shader.hpp>
#include <godot_cpp/classes/display_server.hpp>
#include <godot_cpp/classes/rendering_server.hpp>
#include <godot_cpp/classes/worker_thread_pool.hpp>
#include <godot_cpp/variant/callable_custom.hpp>
#include <functional>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <algorithm>
#include <map>
#include <string>
#include <vector>

namespace rigexec {
using namespace godot;

namespace {

// A control's input is a Double or a Float.
double ScalarValue(const rigExec::RrInputValue &value) {
    return value.tag == rigExec::RrInputTag::Float ? double(value.f32) : value.f64;
}

// REXP version 2 appends rigid-mesh fields (PresentationMesh.transform_path,
// positions, normals) and PresentationMaterial.opacity to presentation.fbs.
// The generated header checked into usdRig predates those fields, so until it
// is regenerated with flatc they are read through the raw table at their
// schema vtable offsets (field index i lives at 4 + 2*i). The v1 generated
// verifier bounds every field it knows; the rigid arrays are additionally
// range-checked by hand below before use.
const flatbuffers::String *MeshTransformPath(const rigExec::fb::PresentationMesh *m) {
    return reinterpret_cast<const flatbuffers::Table *>(m)->GetPointer<const flatbuffers::String *>(24);
}
const flatbuffers::Vector<float> *MeshPositions(const rigExec::fb::PresentationMesh *m) {
    return reinterpret_cast<const flatbuffers::Table *>(m)->GetPointer<const flatbuffers::Vector<float> *>(26);
}
const flatbuffers::Vector<float> *MeshNormals(const rigExec::fb::PresentationMesh *m) {
    return reinterpret_cast<const flatbuffers::Table *>(m)->GetPointer<const flatbuffers::Vector<float> *>(28);
}
float MaterialOpacity(const rigExec::fb::PresentationMaterial *m) {
    return reinterpret_cast<const flatbuffers::Table *>(m)->GetField<float>(22, 1.0f);
}

// Row-vector USD matrices become Godot basis columns and an origin.
Transform3D ToGodot(const rigExec::RrMat4d &m) {
    return Transform3D(
        Basis(Vector3(m[0][0], m[0][1], m[0][2]),
              Vector3(m[1][0], m[1][1], m[1][2]),
              Vector3(m[2][0], m[2][1], m[2][2])),
        Vector3(m[3][0], m[3][1], m[3][2]));
}

Ref<Shader> PresentationShader(bool transparent) {
    Ref<Shader> shader;
    shader.instantiate();
    String code = R"(shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx;
uniform sampler2D ball_texture : source_color, filter_linear_mipmap, repeat_enable;
uniform vec3 diffuse_scale;
uniform vec3 emission_scale;
uniform float roughness;
uniform float metallic;
uniform float specular;
uniform float opacity = 1.0;
void fragment() {
    // Keep U continuous across the wrap seam and T inside the texel centres.
    float half_texel = 0.5 / float(textureSize(ball_texture, 0).y);
    vec3 texel = texture(ball_texture, vec2(UV.x, clamp(UV.y, half_texel, 1.0 - half_texel))).rgb;
    ALBEDO = texel * diffuse_scale;
    EMISSION = texel * emission_scale;
    ROUGHNESS = roughness; METALLIC = metallic; SPECULAR = specular;
)";
    if (transparent) code += "    ALPHA = opacity;\n";
    code += "}\n";
    shader->set_code(code);
    return shader;
}

} // namespace

void RigExecPlayer::_clear_presentation() {
    for (auto &v : _visuals) {
        if (v.node) { remove_child(v.node); memdelete(v.node); }
    }
    _visuals.clear();
    _controls.clear(); _control_slots.clear(); _source_info.clear();
    _has_presentation = false;
}

bool RigExecPlayer::set_control(const String &name, double value) {
    _complete_pending();
    if (!_control_slots.has(name) || !std::isfinite(value)) {
        _last_error = "Expected a finite value for an exposed controller: " + name;
        return false;
    }
    if (!_ensure_reader(&_last_error)) return false;
    const Control &control = _controls[size_t(int64_t(_control_slots[name]))];
    rigExec::RrInputValue held{};
    held.tag = rigExec::RrInputTag::Double;
    held.f64 = value;
    std::string why;
    if (!_reader->SetInputAt(control.input, held, &why)) {
        _last_error = String(why.c_str()); return false;
    }
    _last_error = "";
    return true;
}

Dictionary RigExecPlayer::get_controls() const {
    _complete_pending();
    Dictionary result;
    if (!_reader) return result;
    // Defaults and values come from the file's inputs; the input path is
    // internal wiring, not the game interface.
    for (const Control &control : _controls) {
        Dictionary metadata;
        metadata["name"] = control.name;
        metadata["default"] = ScalarValue(_reader->GetInputInfo(control.input).defaultValue);
        metadata["unit"] = control.unit;
        metadata["value"] = ScalarValue(_reader->GetInputValue(control.input));
        result[control.name] = metadata;
    }
    return result;
}

bool RigExecPlayer::_set(const StringName &name, const Variant &value) {
    const String n(name);
    if (!n.begins_with("controls/")) return false;
    if (value.get_type() != Variant::FLOAT && value.get_type() != Variant::INT) return false;
    return set_control(n.substr(9).replace("/", "."), value) && evaluate();
}

bool RigExecPlayer::_get(const StringName &name, Variant &value) const {
    const String n(name);
    const String key = n.substr(9).replace("/", ".");
    if (!n.begins_with("controls/") || !_control_slots.has(key) || !_reader) return false;
    _complete_pending();
    const Control &control = _controls[size_t(int64_t(_control_slots[key]))];
    value = ScalarValue(_reader->GetInputValue(control.input)); return true;
}

void RigExecPlayer::_get_property_list(List<PropertyInfo> *list) const {
    for (const Control &control : _controls)
        list->push_back(PropertyInfo(Variant::FLOAT, "controls/" + control.name.replace(".", "/")));
}

void RigExecPlayer::_validate_property(PropertyInfo &p) const {
    if (_has_presentation && String(p.name) == "skeleton_path")
        p.usage = PROPERTY_USAGE_STORAGE;
}

bool RigExecPlayer::_load_presentation() {
    auto fail = [&](const String &reason) {
        _clear_presentation(); _last_error = "Invalid embedded presentation: " + reason; return false;
    };
    // _data may be compressed transport bytes. Open through the format
    // decoder before inspecting the owned, validated presentation payload.
    std::unique_ptr<rigExec::fb::RigExecWireFile> file;
    std::string why;
    if (!rigExec::RigExecFormatOpen(_data.ptr(), _data.size(), &file, &why))
        return fail(String::utf8(why.c_str()));
    const std::vector<uint8_t> &buffer = file->presentation;
    if (buffer.empty()) return true;
    flatbuffers::Verifier verifier(buffer.data(), buffer.size());
    if (!rigExec::fb::VerifyPresentationBuffer(verifier)) return fail("REXP buffer");
    const rigExec::fb::Presentation *asset = rigExec::fb::GetPresentation(buffer.data());
    if (asset->version() != 1 && asset->version() != 2) return fail("version");
    // Shader resources and decoded PNGs are shared within this asset. The
    // byte-string key compares full contents, so equal textures decode once.
    Ref<Shader> opaque_shader = PresentationShader(false);
    Ref<Shader> transparent_shader;
    std::map<std::string, Ref<ImageTexture>> textures;
    if (const auto *controls = asset->controls()) {
        for (const rigExec::fb::PresentationControl *c : *controls) {
            const String name = String::utf8(c->name()->c_str(), int(c->name()->size()));
            if (name.is_empty() || name.contains("/") || _control_slots.has(name))
                return fail("controller name");
            size_t input = 0;
            if (!_reader->FindInput(c->input()->str(), &input))
                return fail("control input " + String::utf8(c->input()->c_str()));
            const rigExec::RrInputTag type = _reader->GetInputInfo(input).type;
            if (type != rigExec::RrInputTag::Double && type != rigExec::RrInputTag::Float)
                return fail("control input type");
            const char *unit = nullptr;
            switch (c->unit()) {
            case rigExec::fb::PresentationUnit::AssetUnits: unit = "asset_units"; break;
            case rigExec::fb::PresentationUnit::Degrees: unit = "degrees"; break;
            case rigExec::fb::PresentationUnit::Ratio: unit = "ratio"; break;
            }
            if (!unit) return fail("control unit");
            _control_slots[name] = int64_t(_controls.size());
            _controls.push_back({name, input, unit});
        }
    }
    const auto *meshes = asset->meshes();
    if (!meshes || meshes->size() == 0) return fail("no render meshes");
    for (const rigExec::fb::PresentationMesh *m : *meshes) {
        Visual visual;
        visual.points_path = m->pointsPath()->str();
        visual.rigid = MeshPositions(m) != nullptr;
        const auto *vertices = m->vertexIndices();
        const auto *uv = m->uvs();
        if (!vertices || !uv || vertices->size() == 0 || vertices->size() % 3)
            return fail("triangle/UV count");
        Array rigid_arrays;
        if (visual.rigid) {
            if (asset->version() != 2 || !MeshTransformPath(m) || MeshTransformPath(m)->size() == 0)
                return fail("rigid transform binding");
            if (!visual.points_path.empty() || m->sourcePointCount() != 0 ||
                m->stencilOffsets() || m->stencilIndices16() || m->stencilIndices32() || m->stencilWeights())
                return fail("mixed rigid and stencil geometry");
            visual.transform_path = MeshTransformPath(m)->str();
            const auto *positions = MeshPositions(m);
            const auto *normals = MeshNormals(m);
            if (!normals || positions->size() == 0 || positions->size() % 3 ||
                normals->size() != positions->size() ||
                uv->size() != (size_t(positions->size()) / 3) * 2)
                return fail("rigid vertex/normal/UV count");
            const size_t count = positions->size() / 3;
            PackedVector3Array points, ns;
            points.resize(count); ns.resize(count); visual.uvs.resize(count);
            Vector3 *p = points.ptrw(), *n = ns.ptrw();
            Vector2 *uvs = visual.uvs.ptrw();
            for (size_t i = 0; i < count; ++i) {
                for (size_t k = 0; k < 3; ++k)
                    if (!std::isfinite(positions->Get(3 * i + k)) ||
                        !std::isfinite(normals->Get(3 * i + k)))
                        return fail("rigid vertex/normal value");
                const float u = uv->Get(2 * i), v = uv->Get(2 * i + 1);
                if (!std::isfinite(u) || !std::isfinite(v)) return fail("rigid UV value");
                p[i] = Vector3(positions->Get(3 * i), positions->Get(3 * i + 1), positions->Get(3 * i + 2));
                n[i] = Vector3(normals->Get(3 * i), normals->Get(3 * i + 1), normals->Get(3 * i + 2));
                if (n[i].length_squared() < 1e-12) return fail("rigid zero normal");
                n[i].normalize(); uvs[i] = Vector2(u, v);
            }
            PackedInt32Array indices;
            indices.resize(vertices->size());
            int32_t *dest = indices.ptrw();
            for (uint32_t i = 0; i < vertices->size(); ++i) {
                const uint32_t vi = vertices->Get(i);
                if (vi >= count || vi > uint32_t(INT32_MAX)) return fail("rigid triangle index");
                dest[i] = int32_t(vi);
            }
            rigid_arrays.resize(Mesh::ARRAY_MAX);
            rigid_arrays[Mesh::ARRAY_VERTEX] = points;
            rigid_arrays[Mesh::ARRAY_NORMAL] = ns;
            rigid_arrays[Mesh::ARRAY_TEX_UV] = visual.uvs;
            rigid_arrays[Mesh::ARRAY_INDEX] = indices;
        } else {
            if (MeshTransformPath(m) || MeshNormals(m)) return fail("incomplete rigid geometry");
            const uint32_t source_count = m->sourcePointCount();
            if (source_count == 0 || source_count > uint32_t(INT32_MAX) || visual.points_path.empty())
                return fail("point binding");
            visual.source_count = int(source_count);
            // CSR stencils: three groups (p, u, v) per render vertex.
            const auto *offsets = m->stencilOffsets();
            const auto *weights = m->stencilWeights();
            const auto *indices16 = m->stencilIndices16();
            const auto *indices32 = m->stencilIndices32();
            if (!offsets || !weights || (indices16 == nullptr) == (indices32 == nullptr))
                return fail("stencil tables");
            const size_t entries = indices16 ? indices16->size() : indices32->size();
            if (entries != weights->size() || (indices16 != nullptr) != (source_count <= 65535))
                return fail("stencil indices");
            if (offsets->size() < 4 || (offsets->size() - 1) % 3 != 0 || offsets->Get(0) != 0 ||
                offsets->Get(offsets->size() - 1) != entries)
                return fail("stencil offsets");
            const size_t vertex_count = (offsets->size() - 1) / 3;
            visual.stencils.resize(vertex_count);
            for (size_t i = 0; i < vertex_count; ++i) {
                Stencil &s = visual.stencils[i];
                std::vector<Coefficient> *dest[] = {&s.p, &s.u, &s.v};
                for (size_t group = 0; group < 3; ++group) {
                    const uint32_t begin = offsets->Get(uint32_t(3 * i + group));
                    const uint32_t end = offsets->Get(uint32_t(3 * i + group + 1));
                    if (end <= begin || end > entries) return fail("stencil group");
                    dest[group]->reserve(end - begin);
                    for (uint32_t k = begin; k < end; ++k) {
                        const uint32_t index = indices16 ? indices16->Get(k) : indices32->Get(k);
                        const float w = weights->Get(k);
                        if (index >= source_count || !std::isfinite(w)) return fail("stencil coefficient");
                        dest[group]->push_back({int(index), w});
                    }
                }
            }
            if (uv->size() != 2 * size_t(vertices->size()))
                return fail("triangle/UV count");
            visual.uvs.resize(vertices->size());
            visual.vertices.reserve(vertices->size());
            Vector2 *uvs = visual.uvs.ptrw();
            // A render vertex with one UV across all its corners can keep
            // an indexed surface; conflicting UVs keep corner expansion.
            visual.vertex_uvs.resize(vertex_count);
            Vector2 *vertex_uvs = visual.vertex_uvs.ptrw();
            std::vector<char> uv_seen(vertex_count, 0);
            visual.indexed = true;
            for (uint32_t i = 0; i < vertices->size(); ++i) {
                const uint32_t vi = vertices->Get(i);
                const float u = uv->Get(2 * i), v = uv->Get(2 * i + 1);
                if (vi >= vertex_count || !std::isfinite(u) || !std::isfinite(v))
                    return fail("triangle/UV value");
                visual.vertices.push_back(int(vi)); uvs[i] = Vector2(u, v);
                if (!uv_seen[vi]) { uv_seen[vi] = 1; vertex_uvs[vi] = uvs[i]; }
                else if (vertex_uvs[vi] != uvs[i]) visual.indexed = false;
            }
            if (!visual.indexed) visual.vertex_uvs = PackedVector2Array();
        }
        const rigExec::fb::PresentationMaterial *material = m->material();
        if (!material || !material->model() || material->model()->str() != "UsdPreviewSurface" ||
            material->wrapS() != rigExec::fb::PresentationWrap::Repeat ||
            material->wrapT() != rigExec::fb::PresentationWrap::Clamp)
            return fail("unsupported material model/wrap");
        const auto *png_bytes = material->texturePng();
        if (!png_bytes || png_bytes->size() == 0) return fail("embedded PNG");
        const float opacity = asset->version() == 2 ? MaterialOpacity(material) : 1.0f;
        if (!std::isfinite(opacity) || opacity < 0 || opacity > 1)
            return fail("material opacity");
        const std::string texture_key(reinterpret_cast<const char *>(png_bytes->data()), png_bytes->size());
        auto texture = textures.find(texture_key);
        if (texture == textures.end()) {
            PackedByteArray png;
            png.resize(png_bytes->size());
            std::memcpy(png.ptrw(), png_bytes->data(), png_bytes->size());
            Ref<Image> decoded; decoded.instantiate();
            if (decoded->load_png_from_buffer(png) != OK) return fail("embedded PNG");
            decoded->generate_mipmaps();
            texture = textures.emplace(texture_key, ImageTexture::create_from_image(decoded)).first;
        }
        visual.material.instantiate();
        if (opacity < 1.0f) {
            if (transparent_shader.is_null()) transparent_shader = PresentationShader(true);
            visual.material->set_shader(transparent_shader);
        } else visual.material->set_shader(opaque_shader);
        visual.material->set_shader_parameter("ball_texture", texture->second);
        visual.material->set_shader_parameter("opacity", opacity);
        const rigExec::fb::PresentationColor *colors[] = {material->diffuseScale(), material->emissionScale()};
        const char *color_keys[] = {"diffuse_scale", "emission_scale"};
        for (int k = 0; k < 2; ++k) {
            const rigExec::fb::PresentationColor *c = colors[k];
            if (!c) return fail("material color");
            if (!std::isfinite(c->r()) || !std::isfinite(c->g()) || !std::isfinite(c->b()))
                return fail("material color value");
            visual.material->set_shader_parameter(color_keys[k], Vector3(c->r(), c->g(), c->b()));
        }
        const float scalars[] = {material->roughness(), material->metallic(), material->specular()};
        const char *scalar_keys[] = {"roughness", "metallic", "specular"};
        for (int k = 0; k < 3; ++k) {
            const double v = scalars[k];
            if (!std::isfinite(v) || v < 0 || v > 1) return fail("material scalar");
            visual.material->set_shader_parameter(scalar_keys[k], v);
        }
        visual.mesh.instantiate();
        if (visual.rigid)
            visual.mesh->add_surface_from_arrays(Mesh::PRIMITIVE_TRIANGLES, rigid_arrays);
        visual.node = memnew(MeshInstance3D);
        visual.node->set_name("RigExecGeometry" + String::num_int64(_visuals.size()));
        visual.node->set_mesh(visual.mesh); visual.node->set_material_override(visual.material);
        add_child(visual.node, false, Node::INTERNAL_MODE_BACK);
        _visuals.push_back(std::move(visual));
    }
    _source_info = Dictionary();
    const flatbuffers::String *source = asset->sourceJson();
    if (source && source->size() > 0) {
        Ref<JSON> parser; parser.instantiate();
        if (parser->parse(String::utf8(source->c_str(), int(source->size()))) != OK ||
            parser->get_data().get_type() != Variant::DICTIONARY) return fail("source description");
        _source_info = parser->get_data();
    }
    _has_presentation = true;
    return true;
}

// Godot stores a normal as an octahedral pair in UNORM16 inside an
// 8-byte normal/tangent stream (RenderingServer's format helpers report
// the strides); this mirrors Vector3::octahedron_encode plus the bias.
// Runs fn(i) for i in [0, count) on Godot's WorkerThreadPool and waits.
class IndexedCallable : public CallableCustom {
public:
    explicit IndexedCallable(const std::function<void(int)> *fn) : _fn(fn) {}
    uint32_t hash() const override { return uint32_t(std::hash<const void *>{}(this)); }
    String get_as_text() const override { return "RigExecPrepare"; }
    CompareEqualFunc get_compare_equal_func() const override {
        return [](const CallableCustom *a, const CallableCustom *b) { return a == b; };
    }
    CompareLessFunc get_compare_less_func() const override {
        return [](const CallableCustom *a, const CallableCustom *b) { return a < b; };
    }
    ObjectID get_object() const override { return ObjectID(); }
    bool is_valid() const override { return true; }
    void call(const Variant **args, int argc, Variant &, GDExtensionCallError &error) const override {
        error.error = GDEXTENSION_CALL_OK;
        if (argc > 0) (*_fn)(int(*args[0]));
    }
private:
    const std::function<void(int)> *_fn;
};

void ParallelFor(int count, const std::function<void(int)> &fn) {
    if (count <= 0) return;
    WorkerThreadPool *pool = WorkerThreadPool::get_singleton();
    if (!pool || count == 1) {
        for (int i = 0; i < count; ++i) fn(i);
        return;
    }
    const int64_t group = pool->add_group_task(Callable(memnew(IndexedCallable(&fn))), count, -1, true, "rigExec prepare");
    pool->wait_for_group_task_completion(group);
}

uint32_t OctahedralUnorm16(const Vector3 &normal) {
    const float d = std::fabs(normal.x) + std::fabs(normal.y) + std::fabs(normal.z);
    float ox = 0.0f, oy = 0.0f;
    if (d > 1e-12f) {
        ox = normal.x / d;
        oy = normal.y / d;
        if (normal.z < 0.0f) {
            const float tx = (1.0f - std::fabs(oy)) * (ox >= 0.0f ? 1.0f : -1.0f);
            oy = (1.0f - std::fabs(ox)) * (oy >= 0.0f ? 1.0f : -1.0f);
            ox = tx;
        }
    }
    auto pack = [](float v) -> uint32_t {
        return uint32_t(std::lround(Math::clamp(v * 0.5f + 0.5f, 0.0f, 1.0f) * 65535.0f));
    };
    return pack(ox) | (pack(oy) << 16);
}
PackedVector3Array RigExecPlayer::get_output_points(const String &points_path) {
    _complete_pending();
    PackedVector3Array out;
    if (!_reader || !_evaluated) return out;
    const std::string path = points_path.utf8().get_data();
    for (const auto &o : _reader->GetPoints()) {
        if (o.path != path) continue;
        out.resize(int64_t(o.points.size()));
        Vector3 *w = out.ptrw();
        for (size_t i = 0; i < o.points.size(); ++i) {
            const auto &p = o.points[i];
            w[i] = Vector3(p[0], p[1], p[2]);
        }
        break;
    }
    return out;
}

bool RigExecPlayer::_update_presentation() {
    std::string why;
    if (!_prepare_presentation(&why)) {
        _last_error = String::utf8(why.c_str());
        return false;
    }
    return _commit_presentation();
}

// The CPU half: binds outputs, applies the stencils and, for surfaces
// already on in-place updates, encodes the vertex streams. It touches only
// the runtime's outputs and each Visual's staging, never a Godot object, so
// evaluate_async runs it on its worker thread.
bool RigExecPlayer::_prepare_presentation(std::string *why) {
    const auto &outputs = _reader->GetPoints();
    const auto &transforms = _reader->GetProviderXforms();
    // Serial pass: bindings, rigid transforms, which deforming surfaces
    // changed; sizes their staging. Then the stencil and encoding work runs
    // in parallel chunks (it was ~5.6 ms serial for the 88k-point creature,
    // enough to push most poses past one physics tick).
    struct Job { Visual *v; const rigExec::RigExecRuntimePoints *out; uint8_t *pp; uint8_t *np; };
    std::vector<Job> jobs;
    for (auto &v : _visuals) {
        v.staged = false;
        if (v.rigid) {
            if (v.transform_output < 0 || size_t(v.transform_output) >= transforms.size() ||
                transforms[size_t(v.transform_output)].path != v.transform_path) {
                const auto found = std::find_if(transforms.begin(), transforms.end(), [&](const auto &p) { return p.path == v.transform_path; });
                v.transform_output = found == transforms.end() ? -1 : int(found - transforms.begin());
            }
            if (v.transform_output < 0) {
                *why = "Rig output transform binding mismatch: " + v.transform_path; return false;
            }
            const auto &matrix = transforms[size_t(v.transform_output)].matrix;
            for (size_t row = 0; row < 4; ++row)
                for (size_t col = 0; col < 4; ++col)
                    if (!std::isfinite(matrix[row][col])) {
                        *why = "Non-finite rig output transform: " + v.transform_path; return false;
                    }
            v.staged_transform = ToGodot(matrix);
            v.staged = true;
            continue;
        }
        // The output list is fixed per file; the cached slot is found again
        // only if its path ever differs.
        if (v.points_output < 0 || size_t(v.points_output) >= outputs.size() ||
            outputs[size_t(v.points_output)].path != v.points_path) {
            const auto found = std::find_if(outputs.begin(), outputs.end(), [&](const auto &p) { return p.path == v.points_path; });
            v.points_output = found == outputs.end() ? -1 : int(found - outputs.begin());
        }
        if (v.points_output < 0 || outputs[size_t(v.points_output)].points.size() != size_t(v.source_count)) {
            *why = "Rig output point binding/count mismatch: " + v.points_path; return false;
        }
        const auto &output = outputs[size_t(v.points_output)];
        auto snapshot = output.points.Share();
        if (v.presented_points == snapshot) continue;
        v.staged_positions.resize(v.stencils.size());
        v.staged_normals.resize(v.stencils.size());
        // ptrw() detaches shared storage here, before any parallel writes.
        uint8_t *pp = v.region_update ? v.region_pos_bytes.ptrw() : nullptr;
        uint8_t *np = v.region_update ? v.region_nt_bytes.ptrw() : nullptr;
        jobs.push_back({&v, &output, pp, np});
        v.staged_points = std::move(snapshot);
        v.staged = true;
    }
    if (jobs.empty()) return true;
    constexpr size_t CHUNK = 2048;
    struct Range { size_t job, begin, end; };
    std::vector<Range> stencil_ranges, encode_ranges;
    for (size_t j = 0; j < jobs.size(); ++j) {
        const Visual &v = *jobs[j].v;
        for (size_t a = 0; a < v.stencils.size(); a += CHUNK)
            stencil_ranges.push_back({j, a, std::min(a + CHUNK, v.stencils.size())});
        if (v.region_update) {
            const size_t n = v.indexed ? v.stencils.size() : v.vertices.size();
            for (size_t a = 0; a < n; a += CHUNK) encode_ranges.push_back({j, a, std::min(a + CHUNK, n)});
        }
    }
    const std::function<void(int)> stencil_fn = [&](int r) {
        const Range &rg = stencil_ranges[size_t(r)];
        Visual &v = *jobs[rg.job].v;
        const auto &points = jobs[rg.job].out->points;
        auto apply = [&](const std::vector<Coefficient> &weights) {
            Vector3 result;
            for (const auto &w : weights) {
                const auto &p = points[w.index];
                result += Vector3(p[0], p[1], p[2]) * w.weight;
            }
            return result;
        };
        for (size_t i = rg.begin; i < rg.end; ++i) {
            const auto &s = v.stencils[i];
            v.staged_positions[i] = apply(s.p);
            v.staged_normals[i] = apply(s.u).cross(apply(s.v)).normalized();
        }
    };
    ParallelFor(int(stencil_ranges.size()), stencil_fn);
    // Encode the position and normal streams for an in-place rewrite;
    // topology, UVs and tangents never change.
    const std::function<void(int)> encode_fn = [&](int r) {
        const Range &rg = encode_ranges[size_t(r)];
        const Job &job = jobs[rg.job];
        const Visual &v = *job.v;
        for (size_t i = rg.begin; i < rg.end; ++i) {
            const size_t src = v.indexed ? i : size_t(v.vertices[i]);
            std::memcpy(job.pp + i * size_t(v.region_pos_stride), &v.staged_positions[src], sizeof(Vector3));
            const uint32_t enc = OctahedralUnorm16(v.staged_normals[src]);
            std::memcpy(job.np + i * size_t(v.region_nt_stride), &enc, sizeof(enc));
        }
    };
    ParallelFor(int(encode_ranges.size()), encode_fn);
    return true;
}

// The main-thread half: hands the staged results to Godot.
bool RigExecPlayer::_commit_presentation() {
    // Uploads emit "changed" synchronously; evaluate()/evaluate_async()/
    // set_character() refuse while this is set (see rigexec_player.h).
    struct CommitGuard {
        bool &flag;
        explicit CommitGuard(bool &f) : flag(f) { flag = true; }
        ~CommitGuard() { flag = false; }
    } guard(_committing);
    for (auto &v : _visuals) {
        if (!v.staged) continue;
        v.staged = false;
        if (v.rigid) {
            if (v.node->get_transform() != v.staged_transform) v.node->set_transform(v.staged_transform);
            continue;
        }
        const std::vector<Vector3> &positions = v.staged_positions, &normals = v.staged_normals;
        if (v.region_update) {
            v.mesh->surface_update_vertex_region(0, v.region_pos_offset, v.region_pos_bytes);
            v.mesh->surface_update_vertex_region(0, v.region_nt_offset, v.region_nt_bytes);
        } else {
            PackedVector3Array points, ns;
            Array arrays; arrays.resize(Mesh::ARRAY_MAX);
            if (v.indexed) {
                points.resize(positions.size()); ns.resize(normals.size());
                std::memcpy(points.ptrw(), positions.data(), positions.size() * sizeof(Vector3));
                std::memcpy(ns.ptrw(), normals.data(), normals.size() * sizeof(Vector3));
                PackedInt32Array indices;
                indices.resize(v.vertices.size());
                int32_t *dest = indices.ptrw();
                for (size_t i = 0; i < v.vertices.size(); ++i) dest[i] = int32_t(v.vertices[i]);
                arrays[Mesh::ARRAY_VERTEX] = points; arrays[Mesh::ARRAY_NORMAL] = ns; arrays[Mesh::ARRAY_TEX_UV] = v.vertex_uvs;
                arrays[Mesh::ARRAY_INDEX] = indices;
            } else {
                points.resize(v.vertices.size()); ns.resize(v.vertices.size());
                Vector3 *p = points.ptrw(), *n = ns.ptrw();
                for (size_t i = 0; i < v.vertices.size(); ++i) { p[i] = positions[v.vertices[i]]; n[i] = normals[v.vertices[i]]; }
                arrays[Mesh::ARRAY_VERTEX] = points; arrays[Mesh::ARRAY_NORMAL] = ns; arrays[Mesh::ARRAY_TEX_UV] = v.uvs;
            }
            v.mesh->clear_surfaces(); v.mesh->add_surface_from_arrays(Mesh::PRIMITIVE_TRIANGLES, arrays);
            // Adopt in-place updates from the next pose when the layout is
            // the understood one. The dummy (headless) RenderingServer
            // discards region updates, so headless keeps this rebuild path,
            // whose arrays surface_get_arrays can still read back.
            RenderingServer *rs = RenderingServer::get_singleton();
            DisplayServer *ds = DisplayServer::get_singleton();
            if (rs && ds && ds->get_name() != "headless" && v.mesh->get_surface_count() == 1 && !positions.empty()) {
                const BitField<RenderingServer::ArrayFormat> format = BitField<RenderingServer::ArrayFormat>(int64_t(v.mesh->surface_get_format(0)));
                const int count = int(v.indexed ? positions.size() : v.vertices.size());
                const int pos_stride = int(rs->mesh_surface_get_format_vertex_stride(format, count));
                const int nt_stride = int(rs->mesh_surface_get_format_normal_tangent_stride(format, count));
                if (pos_stride == int(sizeof(Vector3)) && nt_stride == 8) {
                    v.region_pos_stride = pos_stride;
                    v.region_nt_stride = nt_stride;
                    v.region_pos_offset = int(rs->mesh_surface_get_format_offset(format, count, Mesh::ARRAY_VERTEX));
                    v.region_nt_offset = int(rs->mesh_surface_get_format_offset(format, count, Mesh::ARRAY_NORMAL));
                    v.region_pos_bytes.resize(int64_t(pos_stride) * count);
                    v.region_nt_bytes.resize(int64_t(nt_stride) * count);
                    AABB aabb(positions[0], Vector3());
                    for (const Vector3 &q : positions) aabb.expand_to(q);
                    aabb.grow_by(aabb.get_longest_axis_size() * 0.75f + 0.05f);
                    v.node->set_custom_aabb(aabb);
                    v.region_update = true;
                }
            }
        }
        v.presented_points = std::move(v.staged_points);
    }
    return true;
}
} // namespace rigexec
